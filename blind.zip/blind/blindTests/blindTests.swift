//
//  blindTests.swift
//  blindTests
//
//  Created by Birth2Death on 12/14/24.
//

import Testing
@testable import blind

struct blindTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
