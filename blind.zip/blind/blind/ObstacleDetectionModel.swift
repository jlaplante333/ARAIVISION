

import RealityKit
import ARKit
import AudioToolbox

final class ObstacleDetectionModel: ObservableObject {
    private let session = ARKitSession()
    private let provider = PlaneDetectionProvider(alignments: [.horizontal, .vertical])
    let rootEntity = Entity()

    @Published var detectedPlanes: [UUID: String] = [:] // 감지된 평면 정보를 저장
    @Published var entityMap: [UUID: Entity] = [:]
    
    func run() async {
        guard PlaneDetectionProvider.isSupported else {
            print("PlaneDetectionProvider is NOT supported.")
            return
        }

        do {
            try await session.run([provider])
            print("ARKit session is running...")

            for await update in provider.anchorUpdates {
                guard let planeAnchor = update.anchor as? PlaneAnchor else { continue }

                switch update.event {
                case .added, .updated:
                    await handlePlane(anchor: planeAnchor)
                    await updatePlane(update.anchor)
                case .removed:
                    removePlane(anchor: planeAnchor)
                }
            }
        } catch {
            print("ARKit session failed with error: \(error)")
        }
    }
////////////////////////////////////////////////////////
    @MainActor
        func updatePlane(_ anchor: PlaneAnchor) {
            if let entity = entityMap[anchor.id] {
                print("updating existing plane anchor: \(anchor.id), classification: \(anchor.classification.description)")
                let planeEntity = entity.findEntity(named: "plane") as! ModelEntity
                let newMesh = MeshResource.generatePlane(width: anchor.geometry.extent.width, height: anchor.geometry.extent.height)
                planeEntity.model!.mesh = newMesh

                planeEntity.transform = Transform(matrix: anchor.geometry.extent.anchorFromExtentTransform)
            } else {
                print("adding plane anchor: \(anchor), classification: \(anchor.classification.description)")
                // Add a new entity to represent this plane.
                let entity = Entity()

                let material = UnlitMaterial(color: anchor.classification.color)
                let planeEntity = ModelEntity(mesh: .generatePlane(width: anchor.geometry.extent.width, height: anchor.geometry.extent.height), materials: [material])
                planeEntity.name = "plane"
                planeEntity.transform = Transform(matrix: anchor.geometry.extent.anchorFromExtentTransform)

                let textEntity = ModelEntity(
                    mesh: .generateText(anchor.classification.description)
                )
                textEntity.scale = SIMD3(0.01, 0.01, 0.01)

                entity.addChild(planeEntity)
                planeEntity.addChild(textEntity)

                entityMap[anchor.id] = entity
                rootEntity.addChild(entity)
            }

            // originFromAnchorTransform: The location and orientation of a plane in world space.
            entityMap[anchor.id]?.transform = Transform(matrix: anchor.originFromAnchorTransform)
        }
////////////////////////////////////////
    
    @MainActor
    private func handlePlane(anchor: PlaneAnchor) async {
        let planeID = anchor.id
        let description = anchor.classification.description

        // 새 평면 추가 또는 업데이트
        if detectedPlanes[planeID] == nil {
            print("New plane detected: \(description)")
            detectedPlanes[planeID] = description
        } else {
            print("Plane updated: \(description)")
        }

        // 거리 확인 및 경고
        checkProximity(anchor: anchor)
    }

    private func removePlane(anchor: PlaneAnchor) {
        detectedPlanes.removeValue(forKey: anchor.id)
        print("Plane removed: \(anchor.id)")
    }

    private var warningTimer: Timer? // 경고음을 반복적으로 재생하는 타이머
    private var isWarningActive = false // 경고 활성 상태를 추적

    private func checkProximity(anchor: PlaneAnchor) {
        let anchorPosition = SIMD3<Float>(
            anchor.originFromAnchorTransform.columns.3.x,
            anchor.originFromAnchorTransform.columns.3.y,
            anchor.originFromAnchorTransform.columns.3.z
        )
        
        let userPosition: SIMD3<Float>
        switch anchor.classification {
        case .wall, .door:
            userPosition = SIMD3<Float>(0, 5, 0)
        case .table:
            userPosition = SIMD3<Float>(0, -1, 0)
        default:
            userPosition = SIMD3<Float>(0, 0, 0)
        }

        let distance = simd_distance(anchorPosition, userPosition)
        print("Distance calculated: \(distance)")
        
        let threshold = getThreshold(for: anchor.classification)
        print("Threshold for \(anchor.classification): \(threshold)")
        
        if distance < threshold {
            print("\(anchor.classification): Warning triggered at \(distance)m.")
            startWarningSound()
        } else {
            print("Distance is safe: \(distance)m, no warning.")
            stopWarningSound()
        }
//        switch anchor.classification {
//            case .floor:
//                print("Floor detected: no warning triggered.")
//                return // floor인 경우 경고음 생략
//
//            case .table:
//                let tableSensitivityThreshold: Float = 1.5 // table에 대한 거리 임계값
//                if distance < tableSensitivityThreshold {
//                    print("Table detected: Warning triggered at \(distance)m.")
//                    triggerWarning()
//                }
//
//            default:
//                let generalThreshold: Float = 2.5 // 기본 거리 임계값
//                if distance < generalThreshold {
//                    triggerWarning()
//                }
//            }
        
    }

    private func startWarningSound() {
        guard !isWarningActive else {
            print("Warning sound already active.")
            return
        }

        isWarningActive = true
        print("Warning sound started!")
        warningTimer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            self.triggerWarning()
        }
    }


    private func stopWarningSound() {
        // 경고음을 멈추고 타이머를 정리
        isWarningActive = false
        warningTimer?.invalidate()
        warningTimer = nil
    }


    
    private func getThreshold(for classification: PlaneAnchor.Classification) -> Float {
        switch classification {
        case .wall:
            return 4.0 // 벽은 2미터
        case .floor:
            print("Floor detected: no warning triggered.")
            return 0
        case .ceiling:
            print("ceiling detected: no warning triggered.")
            return 0
        case .table:
            return 1.5 // 테이블은 민감하게 반응
        case .door:
            return 3.0 // 문은 벽보다 살짝 민감
        case .seat:
            return 1.0 // 좌석은 사용자와 가까이 있어야 함
        case .window:
            return 3.0 // 창문은 중간 거리
        case .undetermined, .notAvailable, .unknown:
            return 2 // 기본 임계값
        }
    }





    private func triggerWarning() {
        AudioServicesPlaySystemSound(1052) // 경고음 재생
        print("Warning: Obstacle is too close!")
    }
}
