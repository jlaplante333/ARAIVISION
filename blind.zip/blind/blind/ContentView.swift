//import SwiftUI
//import RealityKit
//
//struct ContentView: View {
//    @EnvironmentObject var ObstacleDetectionModel: ObstacleDetectionModel
//    @State private var immersiveSpaceIsShown = false
//    
//    @State private var showImmersiveSpace = false
//    
//    @Environment(\.openImmersiveSpace) var openImmersiveSpace
//    @Environment(\.dismissImmersiveSpace) var dismissImmersiveSpace
//
//
//    var body: some View {
//        VStack {
//            if immersiveSpaceIsShown {
//                RealityView { content in
//                    content.add(ObstacleDetectionModel.rootEntity) // Add root entity
//                }
//                .task {
//                    await ObstacleDetectionModel.run() // Start ARKit session
//                }
//                .frame(maxWidth: .infinity, maxHeight: .infinity)
//
//                Button("Exit Immersive Space") {
//                    immersiveSpaceIsShown = false
//                }
//                .padding()
//                .background(Color.blue)
//                .foregroundColor(.white)
//                .cornerRadius(10)
//            } else {
//                Button("Enter Immersive Space") {
//                    immersiveSpaceIsShown = true
//                }
//                .onChange(of: showImmersiveSpace) { _, newValue in
//                    Task {
//                        if newValue {
//                            switch await openImmersiveSpace(id: "ImmersiveSpace") {
//                            case .opened:
//                                immersiveSpaceIsShown = true
//                            case .error, .userCancelled:
//                                fallthrough
//                            @unknown default:
//                                immersiveSpaceIsShown = false
//                                showImmersiveSpace = false
//                            }
//                        } else if immersiveSpaceIsShown {
//                            await dismissImmersiveSpace()
//                            immersiveSpaceIsShown = false
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
//

import SwiftUI
import RealityKit
import RealityKitContent

struct ContentView: View {

    @State private var showImmersiveSpace = false
    @State private var immersiveSpaceIsShown = false

    @Environment(\.openImmersiveSpace) var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) var dismissImmersiveSpace

    var body: some View {
        VStack {

            Toggle("Start", isOn: $showImmersiveSpace)
                .toggleStyle(.button)
                .padding(.top, 50)
        }
        .padding()
        .onChange(of: showImmersiveSpace) { _, newValue in
            Task {
                if newValue {
                    switch await openImmersiveSpace(id: "ImmersiveSpace") {
                    case .opened:
                        immersiveSpaceIsShown = true
                    case .error, .userCancelled:
                        fallthrough
                    @unknown default:
                        immersiveSpaceIsShown = false
                        showImmersiveSpace = false
                    }
                } else if immersiveSpaceIsShown {
                    await dismissImmersiveSpace()
                    immersiveSpaceIsShown = false
                }
            }
        }
    }
}
