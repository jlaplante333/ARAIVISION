//import SwiftUI
//import RealityKit
//
//struct ImmersiveView: View {
//    private let model = ObstacleDetectionModel ()
//
//    var body: some View {
//        RealityView { content in
//            // Add the initial RealityKit content
//            content.add(model.rootEntity)
//        }
//        .task {
//            await model.run()
//        }
//    }
//}
//
//#Preview {
//    ImmersiveView()
//        .previewLayout(.sizeThatFits)
//}
import SwiftUI
import RealityKit

struct ImmersiveView: View {
    @StateObject private var model = ObstacleDetectionModel()

    var body: some View {
        ZStack {
            RealityView { content in
                content.add(model.rootEntity)
            }
            .task {
                await model.run()
            }

            // 감지된 평면 정보 표시
            VStack {
                Text("Detected Planes:")
                    .font(.headline)
                    .padding()
                ScrollView {
                    ForEach(Array(model.detectedPlanes.keys), id: \.self) { planeID in
                        if let description = model.detectedPlanes[planeID] {
                            Text("• \(description)")
                                .padding(.vertical, 2)
                        }
                    }
                }
                .padding()
                .background(Color.white.opacity(0.8))
                .cornerRadius(10)
                .frame(maxWidth: 300, maxHeight: 150)
                .shadow(radius: 10)

                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    ImmersiveView()
        .previewLayout(.sizeThatFits)
}
